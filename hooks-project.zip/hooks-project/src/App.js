import React, { useState } from 'react';
import Addition from './components/Addition';
import Subtraction from './components/Subtraction';
import Division from './components/Division';

function App() {
  const [additionResult, setAdditionResult] = useState(0);
  const [subtractionResult, setSubtractionResult] = useState(0);
  const [divisionResult, setDivisionResult] = useState(0);

  return React.createElement(
    'div',
    null,
    React.createElement('h2', null, 'Result'),
    React.createElement('p', null, `The result of addition is: ${additionResult}`),
    React.createElement('p', null, `The result of subtraction is: ${subtractionResult}`),
    React.createElement('p', null, `The result of division is: ${divisionResult}`),
    React.createElement(Addition, { setAdditionResult }),
    React.createElement(Subtraction, { setSubtractionResult }),
    React.createElement(Division, { setDivisionResult })
  );
}

export default App;
