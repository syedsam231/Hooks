import React, { useState } from 'react';

function Division({ setDivisionResult }) {
  const [num1, setNum1] = useState('');
  const [num2, setNum2] = useState('');

  const handleDivision = () => {
    const result = parseFloat(num1) / parseFloat(num2);
    setDivisionResult(result);
  };

  return React.createElement(
    'div',
    null,
    React.createElement('h3', null, 'Division'),
    React.createElement('input', { type: 'number', value: num1, onChange: (e) => setNum1(e.target.value) }),
    React.createElement('input', { type: 'number', value: num2, onChange: (e) => setNum2(e.target.value) }),
    React.createElement('button', { onClick: handleDivision }, 'Divide')
  );
}

export default Division;
